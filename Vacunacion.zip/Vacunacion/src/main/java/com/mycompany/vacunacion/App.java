package com.mycompany.vacunacion;

import javax.swing.JOptionPane;

/**
 *
 * @author OARCILA
 */
public class App {

// Rangos de edad
// 0                       50      60      70      80
// -----------------------)|[-----)|[-----)|[-----)|[--------------
    public static String seleccionEtapaVacunacion(int edad) {
        String mensajeEtapa = "No estas priorizado todavia.";

        if (edad >= 80) {
            mensajeEtapa = "Eres de la primera etapa.";
        } else if (edad >= 70) {
            mensajeEtapa = "Eres de la segunda etapa.";
        } else if (edad >= 60) {
            mensajeEtapa = "Eres de la tercera etapa.";
        } else if (edad >= 50) {
            mensajeEtapa = "Eres de la cuarta etapa.";
        }

        return mensajeEtapa;
    }

    // Menejo de errores o excepciones
    // try {}
    // catch (tipo excepcion) {}
    // finally {}
    public static int leerEdad() throws Exception {
        int edad = 0;
        int intentos = 3;

        boolean hayError;
        do {
            try {
                edad = Integer.parseInt(JOptionPane.showInputDialog("Dime tu edad: "));
                hayError = false;
            } catch (NumberFormatException exception) {
                hayError = true;
                intentos--;
                if (intentos == 0) {
                    JOptionPane.showMessageDialog(null, "Ha superado la cantidad de intentos.\n\nIntentelo nuevamente en unos momentos.");
                    throw new Exception("Usuario supero el numero de intentos erroneos");
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor digite bien la informacion");
                }
            }
        } while (hayError);

        return edad;
    }

    public static void main(String[] args) {
        try {
            // Input: Entrada de informacion. lectura de datos
            int edad = leerEdad();

            // Procesamiento: Se procesa la informacion y se producen valores
            String mensajeEtapa = seleccionEtapaVacunacion(edad);

            // Output: Se presentan los resultados al usuario.
            JOptionPane.showMessageDialog(null, mensajeEtapa);
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(null, exception.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, "Nos vemos despues.");
        }
    }
}
